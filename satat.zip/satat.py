import inflect

def number_to_currency_words(number):
    p = inflect.engine()
    currency_words = p.number_to_words(number)
    return f"{currency_words} dollars"

number = 91234592
currency_in_words = number_to_currency_words(number)
print(currency_in_words)
